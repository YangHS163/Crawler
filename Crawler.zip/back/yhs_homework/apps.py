from django.apps import AppConfig


class YhsHomeworkConfig(AppConfig):
    name = 'yhs_homework'
